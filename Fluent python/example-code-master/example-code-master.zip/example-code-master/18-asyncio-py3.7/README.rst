Refactored sample code for Chapter 18 - "Concurrency with asyncio"

From the book "Fluent Python" by Luciano Ramalho (O'Reilly, 2015)
http://shop.oreilly.com/product/0636920032519.do

##################################################################
NOTE: this "18b" directory contains the examples of chapter 18
rewritten using the new async/await syntax available in Python 3.5
ONLY, instead of the "yield-from" syntax which works since Python
3.3 (and will still work with Python 3.5).
##################################################################
